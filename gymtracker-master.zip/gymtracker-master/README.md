# GymTracker


## About
GymTracker is a simple fitness app where you can save your weightlifting workouts, look up the past activities and see the charts of the progress you have made in each exercise you performed.

Project for the Basics of Android Development classes at the University.

Made for Android platform with Kotlin.


## Technologies
Kotlin 3.5.1

Room database 2.2.3

AndroidMPChart v3.1.0